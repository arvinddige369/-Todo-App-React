import './App.css';
import ToDoList from './componants/ToDoList';

function App() {
  return (
    <div className="App">
    <h1>To Do List app</h1>
     <ToDoList/>
    </div>
  );
}

export default App;
