import React, { useState } from 'react'
import TodoItam from './TodoItam'

export default function ToDoList() {

  const [inputValue, setInputvalu] = useState('');

  function addtodo() {
    const newtodo = {
      id: Date.now,
      title: inputValue,
      completed: false,
    };
    setTodos([...todos, newtodo]);
    setInputvalu('');
  }

  const markTaskCompleted = (taskId) => {
    const updateTodo = todos.map(todo => {
      if (todo.id === taskId) {
        return { ...todo, completed: !todo.completed }
      }
      return todo
    })
    setTodos(updateTodo)
  }
  const tasks = [
    { id: 1, title: "Ract app", completed: false },
    { id: 2, title: "Angular App", completed: true },
    { id: 3, title: "Native app", completed: false },
  ];

  const [todos, setTodos] = useState(tasks);
  const deleteTodo = (taskID) => {
    const updateTodo = todos.filter((todo) => todo.id !== taskID)
    setTodos(updateTodo)
  }

  return (
    <div>
      <div className='inputcont'><input className='todoinput' type='text' value={inputValue} onChange={e => setInputvalu(e.target.value)} required/></div>

      <button className='newbtn' type='submit' onClick={addtodo}>Add Todo</button>
      {todos.map(task => (
        <TodoItam key={task.id} task={task} onComplet={() => markTaskCompleted(task.id)} onDelete={() => deleteTodo(task.id)} />
      ))}

    </div>
  )
}
