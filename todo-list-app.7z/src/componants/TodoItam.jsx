import React from 'react'

export default function TodoItam(props) {
    const itameclass = `todoitam ${props.task.completed ? "completed" : ""}`
  return (
    <div className={itameclass}>
    <h2>{props.task.title}</h2>
    <p>Completed: {props.task.completed ? "Yes" : "No"}</p>
    <button onClick={props.onComplet}>Completed</button>
    <button onClick={props.onDelete}>Delete</button>
    </div>
  )
}
